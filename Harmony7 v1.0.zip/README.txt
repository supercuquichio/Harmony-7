Harmony 7
Version 1.0

A Windows 7-inspired customization pack for Windows 10/11.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

FEATURES

• Windows 7-inspired wallpaper
• Harmony 7 sound scheme
• Windows 7 Aero cursors
• Custom Recycle Bin icons
• English, Spanish, and tons of more languages in the installer.
• Easy installation and uninstallation

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

INSTALLATION

1. Run Harmony7-Setup.exe
2. Follow the installer instructions
3. Enjoy Harmony 7!

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

IMPORTANT

The Recycle Bin icon may need a desktop refresh
(F5) when switching between the empty and full states.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

UNINSTALLATION

Use "Harmony 7 - Uninstall" from the Start Menu,
or uninstall Harmony 7 through Windows Settings.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Harmony 7 v1.0
Created by supercuquichio